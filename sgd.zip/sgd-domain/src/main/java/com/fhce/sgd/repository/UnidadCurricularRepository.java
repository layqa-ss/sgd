package com.fhce.sgd.repository;

import org.springframework.data.repository.CrudRepository;

import com.fhce.sgd.model.gestion.UnidadCurricular;

public interface UnidadCurricularRepository extends CrudRepository<UnidadCurricular, Long> {

}
