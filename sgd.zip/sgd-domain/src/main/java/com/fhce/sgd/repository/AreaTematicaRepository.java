package com.fhce.sgd.repository;

import org.springframework.data.repository.CrudRepository;

import com.fhce.sgd.model.gestion.AreaTematica;

public interface AreaTematicaRepository extends CrudRepository<AreaTematica, Long> {

}
