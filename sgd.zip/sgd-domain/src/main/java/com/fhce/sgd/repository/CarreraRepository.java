package com.fhce.sgd.repository;

import org.springframework.data.repository.CrudRepository;

import com.fhce.sgd.model.gestion.Carrera;


public interface CarreraRepository extends CrudRepository<Carrera, Long> {

}
