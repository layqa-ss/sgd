package com.fhce.sgd.repository;

import org.springframework.data.repository.CrudRepository;

import com.fhce.sgd.model.programas.ProgramaIntegrante;


public interface ProgramaIntegranteRepository extends CrudRepository<ProgramaIntegrante, Long> {

}
