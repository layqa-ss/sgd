package com.fhce.sgd.repository;

import org.springframework.data.repository.CrudRepository;

import com.fhce.sgd.model.programas.Programa;


public interface ProgramaRepository extends CrudRepository<Programa, Long> {

}
