package com.fhce.sgd.repository;

import org.springframework.data.repository.CrudRepository;

import com.fhce.sgd.model.gestion.UnidadAcademica;

public interface UnidadAcademicaRepository extends CrudRepository<UnidadAcademica, Long> {

}
